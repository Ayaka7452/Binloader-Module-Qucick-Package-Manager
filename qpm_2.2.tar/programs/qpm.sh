#!/bin/sh
# Quick Package Manager

# Import env:
pkgname=Quick_Package_Manager
ucpath=$(cat /data/binloader/configs/defpath)
grpath=${ucpath}/mods/$pkgname/config/

# Unified package handling function
app_handle() {
    local operation=$1
    local spn=$2
    local group=$3
    local config_file=""
    local user_file=""
    local user_id=""
    local pkg_full_name=""

    # Find config file
    if [ -n "$group" ]; then
        config_file="${grpath}${group}/${spn}"
    else
        # Search all groups
        local found=0
        for g in ${grpath}*; do
            if [ -f "${g}/${spn}" ]; then
                if [ $found -eq 1 ]; then
                    echo "Error: multiple configs found for '$spn'"
                    return 1
                fi
                config_file="${g}/${spn}"
                group=$(basename "$g")
                found=1
            fi
        done
        if [ $found -eq 0 ]; then
            echo "Error: no config found for '$spn'"
            return 1
        fi
    fi

    # Check if config file exists
    if [ ! -f "$config_file" ]; then
        echo "Error: config file not found"
        return 1
    fi

    # Read package name
    pkg_full_name=$(cat "$config_file")

    # Check for user file
    user_file="${grpath}${group}/.${spn}.user"
    if [ -f "$user_file" ]; then
        user_id=$(cat "$user_file")
    fi

    # Execute pm command
    if [ -n "$user_id" ]; then
        pm "$operation" --user "$user_id" "$pkg_full_name"
    else
        pm "$operation" "$pkg_full_name"
    fi

    return $?
}

case $1 in
help)
 echo "QPM - Android Quick Package Manager"
 echo "Usage: qpm [operation] [parameter1] [...2]"
 echo "Parameter defines:"
 echo "   spn - short package name is specified by user, it related to a full package name."
 echo "   rpn - real package name of a android package, such as com.android.phone."
 echo "   pgn - package group name is specified by user, it contains a bunch of spns."
 echo "Operations:"
 echo "   auto [spn] - Set specified package to opposed state."
 echo "   ag [pgn] - Set specified group to opposed state."
 echo "   ena [spn] - Set package state as enable."
 echo "   disa [spn] - Set package state as disable."
 echo "   addgrp [pgn] - Add a new package group using specified name."
 echo "   addcfg [pgn] [spn] [fpn] - Add a package into exist group."
 echo "   rmcfg [pgn] [spn] - Remove a package config in group."
 echo "   rmgrp [pgn] - Remove a group and its contents."
 echo "   lsgrp - List all groups."
 echo "   dg [pgn] - Disable the whole package group."
 echo "   eg [pgn] - Enable the whole package group."
 echo "   catcfg [pgn] [spn] - display full package name of a config."
 echo "   rngrp [old_pgn] [new_pgn] - Rename a package group."
 echo "   rncfg [pgn] [old_spn] [new_spn] - Rename a short package config."
 echo "   lscfg [pgn] - List configs in group."
 echo "Created by Ayaka7452"
 exit
;;
ag)
    if [ -z "$2" ]; then
        echo "Error: missing package group name."
        exit 1
    fi

    group_path="${grpath}$2"
    state_file="${group_path}/.LastGrpState"

    if [ ! -d "$group_path" ]; then
        echo "Error: no such group."
        exit 1
    fi

    # Initialize or read state
    if [ ! -f "$state_file" ]; then
        echo "enabled" > "$state_file"
    fi
    lastState=$(cat "$state_file")

    # Determine new state
    case $lastState in
        enabled) new_state="disabled";;
        disabled) new_state="enabled";;
        *) echo "Error: invalid state"; exit 1;;
    esac

    # Process each package
    for pkgrec in "$group_path"/*; do
        if [ -f "$pkgrec" ] && [ "$(basename "$pkgrec")" != ".LastGrpState" ]; then
            spn=$(basename "$pkgrec")
            if [ "$new_state" = "disabled" ]; then
                app_handle disable "$spn" "$2"
            else
                app_handle enable "$spn" "$2"
            fi
        fi
    done

    # Update state
    echo "$new_state" > "$state_file"
;;
auto)
    if [ -z "$2" ]; then
        echo "Error: missing short package name."
        exit 1
    fi

    # Find config file
    found_config=""
    for g in ${grpath}*; do
        if [ -f "${g}/$2" ]; then
            if [ -n "$found_config" ]; then
                echo "Error: multiple configs found for '$2'"
                exit 1
            fi
            found_config="${g}/$2"
        fi
    done

    if [ -z "$found_config" ]; then
        echo "Error: no config found for '$2'"
        exit 1
    fi

    # Get full package name
    pkg_full_name=$(cat "$found_config")

    # Determine current state
    if pm list packages -d | grep -q "$pkg_full_name"; then
        app_handle enable "$2"
    else
        app_handle disable "$2"
    fi
;;
disa)
    if [ -z "$2" ]; then
        echo "Error: missing short package name."
        exit 1
    fi
    app_handle disable "$2"
;;
ena)
    if [ -z "$2" ]; then
        echo "Error: missing short package name."
        exit 1
    fi
    app_handle enable "$2"
;;
dg)
    if [ -z "$2" ]; then
        echo "Error: missing package group name."
        exit 1
    fi
    group_path="${grpath}$2"
    if [ ! -d "$group_path" ]; then
        echo "Error: no such package group."
        exit 1
    fi
    for pkgrec in "$group_path"/*; do
        if [ -f "$pkgrec" ]; then
            spn=$(basename "$pkgrec")
            app_handle disable "$spn" "$2"
        fi
    done
;;
eg)
    if [ -z "$2" ]; then
        echo "Error: missing package group name."
        exit 1
    fi
    group_path="${grpath}$2"
    if [ ! -d "$group_path" ]; then
        echo "Error: no such package group."
        exit 1
    fi
    for pkgrec in "$group_path"/*; do
        if [ -f "$pkgrec" ]; then
            spn=$(basename "$pkgrec")
            app_handle enable "$spn" "$2"
        fi
    done
;;
lsgrp)
    ls "${grpath}"
;;
addgrp)
    if [ -z "$2" ]; then
        echo "Error: missing package group name."
        exit 1
    fi
    if [ ! -d "${grpath}${2}" ]; then
        mkdir "${grpath}${2}"
    else
        echo "Error: package group already exists."
        exit 1
    fi
;;
lscfg)
    if [ -z "$2" ]; then
        echo "Error: missing package group name."
        exit 1
    fi
    if [ -d "${grpath}${2}" ]; then
        ls "${grpath}${2}"
    else
        echo "Error: no such package group."
        exit 1
    fi
;;
rmgrp)
    if [ -z "$2" ]; then
        echo "Error: missing package group name."
        exit 1
    fi
    if [ -d "${grpath}${2}" ]; then
        rm -rf "${grpath}${2}"
    else
        echo "Error: no such package group."
        exit 1
    fi
;;
addcfg)
    if [ -z "$2" ]; then
        echo "Error: missing package group name."
        exit 1
    fi
    if [ -z "$3" ]; then
        echo "Error: missing package name."
        exit 1
    fi
    if [ -z "$4" ]; then
        echo "Error: missing full package name."
        exit 1
    fi
    if [ ! -d "${grpath}${2}" ]; then
        echo "Error: no such package group."
        exit 1
    fi
    if [ -f "${grpath}${2}/${3}" ]; then
        echo "Error: config already exists."
        exit 1
    fi
    echo "$4" > "${grpath}${2}/${3}"
;;
rmcfg)
    if [ -z "$2" ]; then
        echo "Error: missing package group name."
        exit 1
    fi
    if [ -z "$3" ]; then
        echo "Error: missing package name."
        exit 1
    fi
    if [ -f "${grpath}${2}/${3}" ]; then
        rm "${grpath}${2}/${3}"
    else
        echo "Error: no such config."
        exit 1
    fi
;;
catcfg)
    if [ -z "$2" ]; then
        echo "Error: missing package group name."
        exit 1
    fi
    if [ -z "$3" ]; then
        echo "Error: missing package name."
        exit 1
    fi
    if [ -f "${grpath}${2}/${3}" ]; then
        cat "${grpath}${2}/${3}"
    else
        echo "Error: no such config."
        exit 1
    fi
;;
rngrp)
    if [ -z "$2" ]; then
        echo "Error: missing old group name."
        exit 1
    fi
    if [ -z "$3" ]; then
        echo "Error: missing new group name."
        exit 1
    fi
    if [ -d "${grpath}$2" ]; then
        mv "${grpath}$2" "${grpath}$3"
    else
        echo "Error: no such package group."
        exit 1
    fi
;;
rncfg)
    if [ -z "$2" ]; then
        echo "Error: missing package group name."
        exit 1
    fi
    if [ -z "$3" ]; then
        echo "Error: missing old package name."
        exit 1
    fi
    if [ -z "$4" ]; then
        echo "Error: missing new package name."
        exit 1
    fi
    if [ -f "${grpath}$2/$3" ]; then
        mv "${grpath}$2/$3" "${grpath}$2/$4"
    else
        echo "Error: no such short package config."
        exit 1
    fi
;;
*)
    echo "Error: missing options or bad options."
    exit 1
;;
esac
